AskAI PWA files
================

Upload ALL files from this folder to the ROOT of the GitHub Pages repository:
- index.html (contains only a manifest link and service-worker registration addition; existing app code is otherwise preserved)
- manifest.json
- sw.js
- askai-logo.jpg (keeps the existing favicon URL valid)
- askai-icon-192.png
- askai-icon-512.png

Important:
- These files do not replace Gemini API or change chat/login/upload functions.
- sw.js intentionally does not cache or intercept requests.
- After committing, open the live site over HTTPS, then re-run the PWABuilder report.
- PWABuilder may still show other warnings; package only after checking the report.
