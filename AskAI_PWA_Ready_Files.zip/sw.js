/* AskAI service worker: registration support only.
   It deliberately does not cache/intercept requests, so current Gemini/API/login behavior is not altered. */
const CACHE_VERSION = "askai-pwa-v1";
self.addEventListener("install", (event) => {
  self.skipWaiting();
});
self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});
